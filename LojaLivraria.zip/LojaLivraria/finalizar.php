<?php
session_start();
include "conexao.php";

// Verifica se existe carrinho
if (!isset($_SESSION['carrinho']) || count($_SESSION['carrinho']) == 0) {
    die("Carrinho vazio.");
}

// Verifica cliente logado
if (!isset($_SESSION['cliente_id'])) {
    die("É necessário estar logado para finalizar a compra.");
}

$cliente_id = $_SESSION['cliente_id'];
$carrinho = $_SESSION['carrinho'];

// Buscar os livros
$ids = implode(",", array_keys($carrinho));
$sql = "SELECT * FROM tb_livro WHERE id_livro IN ($ids)";
$result = $conexao->query($sql);

$totalCompra = 0;
$itens = [];

while ($l = $result->fetch_assoc()) {
    $id = $l['id_livro'];
    $quantidade = $carrinho[$id];
    $subtotal = $l['preco'] * $quantidade;
    $totalCompra += $subtotal;

    $itens[] = [
        "id_livro" => $id,
        "qtd" => $quantidade,
        "preco" => $l['preco'],
        "subtotal" => $subtotal
    ];
}

// 1️⃣ REGISTRAR COMPRA
$sql_compra = "INSERT INTO tb_compra (id_cliente, total_compra)
               VALUES (?, ?)";

$stmt = $conexao->prepare($sql_compra);
$stmt->bind_param("id", $cliente_id, $totalCompra);
$stmt->execute();

$id_compra = $stmt->insert_id; // <-- ID da compra criada
$stmt->close();

// 2️⃣ REGISTRAR ITENS DA COMPRA (item_venda)
foreach ($itens as $i) {

    $sql_item = "INSERT INTO tb_item_venda 
                (id_compra, id_livro, qtd_venda, valor_item, total_item)
                VALUES (?, ?, ?, ?, ?)";

    $stmt = $conexao->prepare($sql_item);
    $stmt->bind_param(
        "iiidd",
        $id_compra,
        $i['id_livro'],
        $i['qtd'],
        $i['preco'],
        $i['subtotal']
    );
    $stmt->execute();
}

// 3️⃣ LIMPAR CARRINHO
unset($_SESSION['carrinho']);

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Compra Finalizada</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="popup" style="display:flex;">
    <div class="popup-content">
        <h2>✅ Compra Finalizada com Sucesso!</h2>
        <p>Obrigado por comprar conosco!</p>

        <a href="index.html" class="btn-popup">Voltar ao Início</a>
    </div>
</div>

</body>
</html>
