<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "db_lojalivro";

$conexao = new mysqli($servidor, $usuario, $senha, $banco);

if ($conexao->connect_error) {
    die("Erro de conexão: " . $conexao->connect_error);
}
?>
