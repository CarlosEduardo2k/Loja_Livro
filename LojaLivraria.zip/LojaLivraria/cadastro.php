<?php
include "conexao.php";

$mostrarPopup = false;

/* ==============================
    CADASTRAR LIVRO
================================ */
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["nome"])) {

    $nome = $_POST['nome'];
    $preco = $_POST['preco'];
    $quantidade = $_POST['quantidade'];

    $sql = "INSERT INTO tb_livro (nome, preco, estoque) VALUES (?, ?, ?)";

    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("sdi", $nome, $preco, $quantidade);

    if ($stmt->execute()) {
        $mostrarPopup = true;
    }

    $stmt->close();
}


/* ==============================
    EXCLUIR LIVRO
================================ */

if (isset($_GET['excluir'])) {

    $id = $_GET['excluir'];

    $sqlDel = "DELETE FROM tb_livro WHERE id_livro = ?";
    $stmtDel = $conexao->prepare($sqlDel);
    $stmtDel->bind_param("i", $id);

    $stmtDel->execute();
    $stmtDel->close();

    header("Location: cadastro.php");  
    exit;
}


/* ==============================
    BUSCAR LIVROS PARA LISTAGEM
================================ */
$livros = $conexao->query("SELECT * FROM tb_livro ORDER BY id_livro DESC");

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Livro</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Cadastrar Novo Livro</h1>
</header>

<main class="container-form">

    <!-- FORMULÁRIO -->
    <form method="post" class="form-livro">
        <label for="nome">Nome do Livro:</label>
        <input type="text" id="nome" name="nome" placeholder="Digite o nome do livro" required>

        <label for="preco">Preço (R$):</label>
        <input type="number" step="0.01" id="preco" name="preco" placeholder="Digite o preço" required>

        <label for="quantidade">Quantidade:</label>
        <input type="number" id="quantidade" name="quantidade" placeholder="Digite a quantidade" required>

        <button type="submit" class="btn">Cadastrar Livro</button>
    </form>
</main>


<!-- LISTAGEM DOS LIVROS -->
<section class="container">
    <table class="tabela-livros">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Preço</th>
                <th>Quantidade</th>
                <th>Excluir</th>
            </tr>
        </thead>
        <tbody>
            <?php while($linha = $livros->fetch_assoc()): ?>
            <tr>
                <td><?= $linha['nome'] ?></td>
                <td>R$ <?= number_format($linha['preco'], 2, ',', '.') ?></td>
                <td><?= $linha['estoque'] ?></td>
                <td>
                    <a href="?excluir=<?= $linha['id_livro'] ?>" 
                       onclick="return confirm('Tem certeza que deseja excluir este livro?')" 
                       class="btn-remover">
                        Excluir
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</section>


<!-- POP-UP -->
<div id="popup" class="popup">
    <div class="popup-content">
        <h2>✔ Livro cadastrado com sucesso!</h2>
        <button onclick="fecharPopup()" class="btn-popup">OK</button>
    </div>
</div>

<script>
function mostrarPopup() {
    document.getElementById('popup').style.display = 'flex';
}

function fecharPopup() {
    document.getElementById('popup').style.display = 'none';
}
</script>

<?php if ($mostrarPopup): ?>
<script>
    mostrarPopup();
</script>
<?php endif; ?>

<footer>
    <a href="index.html" class="btn-voltar">⬅ Voltar à Página Inicial</a>
</footer>

</body>
</html>
