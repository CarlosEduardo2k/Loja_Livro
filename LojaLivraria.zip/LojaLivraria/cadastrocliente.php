<?php        
include "conexao.php";

$popup = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $telefone = $_POST["telefone"];
    $endereco = $_POST["endereco"];

    // Agora também salvando endereço no banco
    $sql = "INSERT INTO tb_cliente (nome, telefone, email) VALUES (?,?,?)";

    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("sss", $nome, $telefone, $email);

    if ($stmt->execute()) {

        // 🔥 ID do cliente recém cadastrado
        $id_cliente = $stmt->insert_id;

        // 🔥 Salvar sessão (cliente logado)
        $_SESSION["cliente_id"] = $id_cliente;
        $_SESSION["cliente_nome"] = $nome;

        $popup = true;
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Cliente</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Cadastro de Cliente</h1>
</header>

<main class="container-form">
    <form class="form-livro" method="POST">

        <label>Nome Completo:</label>
        <input type="text" name="nome" required>

        <label>E-mail:</label>
        <input type="email" name="email" required>

        <label>Telefone:</label>
        <input type="text" name="telefone" required>

        <label>Endereço:</label>
        <input type="text" name="endereco" required>

        <div style="text-align:center; margin-top:20px;">
            <button class="btn-finalizar" type="submit">Cadastrar Cliente</button>
        </div>

    </form>
</main>

<!-- POPUP DE SUCESSO -->
<div id="popup" class="popup">
    <div class="popup-content">
        <h2>Cliente cadastrado e logado com sucesso!</h2>
        <a href="index.html" class="btn-popup">OK</a>
    </div>
</div>

<?php if ($popup): ?>
<script>
document.getElementById('popup').style.display = 'flex';
</script>
<?php endif; ?>

<footer>
    <a href="index.html" class="btn-voltar">⬅ Voltar à Página Inicial</a>
</footer>

</body>
</html>
