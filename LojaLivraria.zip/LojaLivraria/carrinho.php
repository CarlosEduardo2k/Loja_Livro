<?php
include "conexao.php";

// Se não existir carrinho, cria vazio
if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

$cliente_logado = isset($_SESSION['cliente_id']); // <-- verifica login

// Remover item
if (isset($_GET['remover'])) {
    $id = intval($_GET['remover']);
    unset($_SESSION['carrinho'][$id]);
    header("Location: carrinho.php");
    exit;
}

// Buscar livros do carrinho
$itens = $_SESSION['carrinho'];
$livros = [];

$totalGeral = 0;

if (count($itens) > 0) {
    $ids = implode(",", array_keys($itens));
    $sql = "SELECT * FROM tb_livro WHERE id_livro IN ($ids)";
    $result = $conexao->query($sql);

    while ($l = $result->fetch_assoc()) {
        $id = $l['id_livro'];
        $quantidade = $itens[$id];
        $subtotal = $l['preco'] * $quantidade;
        $totalGeral += $subtotal;

        $livros[] = [
            "nome" => $l['nome'],
            "preco" => $l['preco'],
            "quantidade" => $quantidade,
            "subtotal" => $subtotal,
            "id" => $id
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header class="top-nav">
    <h1>Carrinho</h1>
</header>

<main class="container-carrinho">
    <table class="tabela-livros">
        <thead>
            <tr>
                <th>Nome do Livro</th>
                <th>Preço</th>
                <th>Qtd</th>
                <th>Subtotal</th>
                <th></th>
            </tr>
        </thead>

        <tbody>
        <?php if (count($livros) > 0): ?>
            <?php foreach ($livros as $l): ?>
            <tr>
                <td><?= $l['nome'] ?></td>
                <td>R$ <?= number_format($l['preco'], 2, ',', '.') ?></td>
                <td><?= $l['quantidade'] ?></td>
                <td>R$ <?= number_format($l['subtotal'], 2, ',', '.') ?></td>
                <td>
                    <a href="carrinho.php?remover=<?= $l['id'] ?>" class="btn-remover">Remover</a>
                </td>
            </tr>
            <?php endforeach; ?>

        <?php else: ?>
            <tr><td colspan="5" style="text-align:center;">Carrinho vazio</td></tr>
        <?php endif; ?>
        </tbody>
    </table>

<div class="resumo-carrinho">
    <div class="lado-esquerdo">
        <a href="livros.php" class="btn-voltar">⬅ Voltar à Lista</a>
    </div>

    <div class="lado-direito">
        <h2>Total: R$ <?= number_format($totalGeral, 2, ',', '.') ?></h2>

        <?php if ($cliente_logado): ?>
            <form action="finalizar.php" method="POST">
                <button class="btn-finalizar" type="submit">Finalizar Compra</button>
            </form>

        <?php else: ?>
            <a href="cadastrocliente.php" class="btn-finalizar" style="background:#c0392b;">
                Cadastre-se para Finalizar
            </a>
        <?php endif; ?>

    </div>
</div>

</main>

</body>
</html>
