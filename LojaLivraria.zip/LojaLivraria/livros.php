<?php
include "conexao.php";

// Se o usuário clicou em ADICIONAR AO CARRINHO
if (isset($_GET['add'])) {

    $id = intval($_GET['add']);

    // cria o carrinho se não existir
    if (!isset($_SESSION['carrinho'])) {
        $_SESSION['carrinho'] = [];
    }

    // se já existe o item, aumenta quantidade
    if (isset($_SESSION['carrinho'][$id])) {
        $_SESSION['carrinho'][$id]++;
    } else {
        $_SESSION['carrinho'][$id] = 1;
    }

    // redireciona para evitar reenvio
    header("Location: livros.php");
    exit;
}

// buscar livros no banco
$sql = "SELECT * FROM tb_livro";
$result = $conexao->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Livros</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>

<header class="top-nav">
    <h1>Lista de Livros</h1>
    
    <!-- Contador do carrinho -->
    <div class="carrinho" onclick="window.location='carrinho.php'">
        <span class="material-icons">shopping_cart</span>
        <span class="contador">
            <?= isset($_SESSION['carrinho']) ? array_sum($_SESSION['carrinho']) : 0 ?>
        </span>
    </div>
</header>

<main class="container">
    <table class="tabela-livros">
        <thead>
            <tr>
                <th>Nome do Livro</th>
                <th>Preço</th>
                <th>Estoque</th>
                <th></th>  <!-- Tiramos o nome “Ações” -->
            </tr>
        </thead>
        <tbody>

        <?php while ($livro = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $livro['nome'] ?></td>
                <td>R$ <?= number_format($livro['preco'], 2, ',', '.') ?></td>
                <td><?= $livro['estoque'] ?></td>
                <td>
                    <a href="livros.php?add=<?= $livro['id_livro'] ?>" class="btn-add">
                        Adicionar ao Carrinho
                    </a>
                </td>
            </tr>
        <?php endwhile; ?>

        </tbody>
    </table>
</main>

<footer class="rodape">
    <a href="index.html" class="btn-voltar">⬅ Voltar à Página Inicial</a>
</footer>

</body>
</html>
