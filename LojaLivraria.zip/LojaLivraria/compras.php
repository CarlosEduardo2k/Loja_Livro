<?php
include "conexao.php";

// Busca todas as compras com nome do cliente
$sql = "
    SELECT c.id_compra, c.dt_compra, c.total_compra, 
           cli.nome AS cliente
    FROM tb_compra c
    INNER JOIN tb_cliente cli ON cli.id_cliente = c.id_cliente
    ORDER BY c.id_compra DESC
";

$result = $conexao->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Compras</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="no-bg">

<header>
    <h1>Lista de Compras Realizadas</h1>
</header>

<main class="container">
<?php if ($result->num_rows > 0): ?>

    <?php while ($compra = $result->fetch_assoc()): ?>

        <div class="card" style="width:100%; max-width:800px; margin:20px auto;">
            
            <h2>Compra #<?= $compra['id_compra'] ?></h2>
            <p><strong>Cliente:</strong> <?= $compra['cliente'] ?></p>
            <p><strong>Data:</strong> <?= $compra['dt_compra'] ?></p>
            <p><strong>Total:</strong> R$ <?= number_format($compra['total_compra'], 2, ',', '.') ?></p>

            <h3>Itens da compra</h3>

            <table class="tabela-livros">
                <thead>
                    <tr>
                        <th>Livro</th>
                        <th>Qtd</th>
                        <th>Preço</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>

                <?php
                $idCompra = $compra['id_compra'];
                $sqlItens = "
                    SELECT l.nome, i.qtd_venda, i.valor_item, i.total_item
                    FROM tb_item_venda i
                    INNER JOIN tb_livro l ON l.id_livro = i.id_livro
                    WHERE i.id_compra = $idCompra
                ";
                $itens = $conexao->query($sqlItens);

                while ($item = $itens->fetch_assoc()):
                ?>

                    <tr>
                        <td><?= $item['nome'] ?></td>
                        <td><?= $item['qtd_venda'] ?></td>
                        <td>R$ <?= number_format($item['valor_item'], 2, ',', '.') ?></td>
                        <td>R$ <?= number_format($item['total_item'], 2, ',', '.') ?></td>
                    </tr>

                <?php endwhile; ?>

                </tbody>
            </table>
        </div>

    <?php endwhile; ?>

<?php else: ?>
    <p style="text-align:center;">Nenhuma compra registrada ainda.</p>
<?php endif; ?>
</main>

<footer>
    <a href="index.html" class="btn-voltar">⬅ Voltar à Página Inicial</a>
</footer>

</body>
</html>
